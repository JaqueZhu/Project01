package com.bluez.offline

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.mllib.recommendation.{ALS, Rating}
import org.jblas.DoubleMatrix

case class ProductRating(userId: Int, productId: Int, score: Double, timestamp: Long)

case class MongoConfig(uri:String,db:String)

case class Recommendation(productId:Int,score:Double)

case class UserRecs(userId:Int,recs:Seq[Recommendation])

case class ProductRecs(productId:Int,recs:Seq[Recommendation])


object OfflineRecommender {
  // 定义常量，指定 MongoDB 中存储评分数据的集合名称
  val MONGODB_RATING_COLLECTION = "Rating"

  // 定义常量，指定推荐结果存储到 MongoDB 的集合名称
  val USER_RECS = "UserRecs"
  val PRODUCT_RECS = "ProductRecs"

  // 定义常量，指定每个用户最大推荐数量
  val USER_MAX_RECOMMENDATION = 20

  def main(args: Array[String]): Unit = {
    // 定义配置参数，包括 Spark 运行模式和 MongoDB 连接信息
    val config = Map(
      "spark.cores" -> "local[*]", // Spark 运行模式，使用本地所有核心
      "mongo.uri" -> "mongodb://hdp01:27017/recommender", // MongoDB 连接 URI
      "mongo.db" -> "recommender" // MongoDB 数据库名称
    )

    // 创建 Spark 配置对象，设置应用程序名称和运行模式
    val sparkConf = new SparkConf().setMaster(config("spark.cores")).setAppName("OfflineRecommender")
      .set("spark.testing.memory", "512000000")

    // 创建 SparkSession 对象，它是使用 Spark SQL 功能的入口点
    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    // 声明隐式的 MongoDB 配置对象，以便在后续操作中使用
    implicit val mongoConfig = MongoConfig(config("mongo.uri"), config("mongo.db"))

    // 导入 SparkSession 的隐式转换，以便将 RDD 转换为 DataFrame
    import spark.implicits._

    // 从 MongoDB 读取评分数据，并将其转换为 ProductRating 类型的 RDD
    val ratingRDD = spark
      .read
      .option("uri", mongoConfig.uri) // 设置 MongoDB 连接 URI
      .option("collection", MONGODB_RATING_COLLECTION) // 设置读取的集合名称
      .format("com.mongodb.spark.sql") // 设置数据源格式为 MongoDB
      .load() // 读取数据
      .as[ProductRating] // 将读取的数据转换为 ProductRating 类型的 RDD
      .rdd // 获取 RDD
      .map(rating => (rating.userId, rating.productId, rating.score)) // 将每个评分转换为三元组 (userId, productId, score)
      .cache() // 缓存 RDD，以便后续操作
    //从评分数据中提取出所有用户 ID 和所有产品 ID 的 RDD（去重后的）
    val userRDD=ratingRDD.map(_._1).distinct()
    val productRDD=ratingRDD.map(_._2).distinct()

    val trainData=ratingRDD.map(x=>Rating(x._1,x._2,x._3))

    val (rank,iterations,lambda)=(200,5,0.01)

    val model=ALS.train(trainData,rank, iterations,lambda)

    val userProducts=userRDD.cartesian(productRDD)

    val preRatings=model.predict(userProducts)

    val userRecs=preRatings
      .filter(_.rating>0)
      .map(rating=>(rating.user,(rating.product,rating.rating)))
      .groupByKey()
      .map{
        case (userId,recs)=>{
          UserRecs(userId ,recs.toList.sortWith(_._2>_._2)
          .take(USER_MAX_RECOMMENDATION)
          .map(x=>Recommendation(x._1,x._2)))
        }
      }.toDF()
    // 将用户推荐列表 DataFrame 存储到 MongoDB
    userRecs.write
      .option("uri",mongoConfig.uri)
      .option("collection",USER_RECS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    val productFeatures=model.productFeatures.map{
      case (productId,features)=>(productId,new DoubleMatrix(features))
    }
    val productRecs = productFeatures.cartesian(productFeatures).filter{
      case(a,b)=>a._1!=b._1
    }.map{
      case(a,b)=>
        val simScore=this.consinSim(a._2,b._2)
        (a._1,(b._1,simScore))
    }.filter(_._2._2>0.6).groupByKey()
      .map{
        case(productId,items)=>{
          ProductRecs(productId,items.toList.map(x=>Recommendation(x._1,x._2)))
        }
      }.toDF()

    productRecs.write
      .option("uri",mongoConfig.uri)
      .option("collection",PRODUCT_RECS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    spark.close()
  }

  def consinSim(product1: DoubleMatrix, product2: DoubleMatrix):Double={
    product1.dot(product2)/(product1.norm2()*product2.norm2())
  }

}
