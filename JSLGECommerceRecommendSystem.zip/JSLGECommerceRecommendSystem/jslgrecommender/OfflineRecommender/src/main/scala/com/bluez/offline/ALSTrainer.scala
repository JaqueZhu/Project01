package com.bluez.offline

import breeze.numerics.sqrt
import org.apache.spark.SparkConf
import org.apache.spark.mllib.recommendation.{ALS, MatrixFactorizationModel, Rating}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession


object ALSTrainer {

  def main(args: Array[String]): Unit = {
    val config = Map(
      "spark.cores" -> "local[*]", // Spark 运行模式，使用本地所有核心
      "mongo.uri" -> "mongodb://hdp01:27017/recommender", // MongoDB 连接 URI
      "mongo.db" -> "recommender" // MongoDB 数据库名称
    )
    // 创建 Spark 配置对象，设置应用程序名称和运行模式
    val sparkConf = new SparkConf().setMaster(config("spark.cores")).setAppName("OfflineRecommender")
      .set("spark.testing.memory", "512000000")

    // 创建 SparkSession 对象，它是使用 Spark SQL 功能的入口点
    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    // 声明隐式的 MongoDB 配置对象，以便在后续操作中使用
    implicit val mongoConfig = MongoConfig(config("mongo.uri"), config("mongo.db"))

    // 导入 SparkSession 的隐式转换，以便将 RDD 转换为 DataFrame
    import spark.implicits._
    val ratingRDD=spark
      .read
      .option("uri",mongoConfig.uri)
      .option("collection",OfflineRecommender.MONGODB_RATING_COLLECTION)
      .format("com.mongodb.spark.sql")
      .load()
      .as[ProductRating]
      .rdd
      .map(rating=>Rating(rating.userId,rating.productId,rating.score))
      .cache()

    val splits=ratingRDD.randomSplit(Array(0.8,0.2))

    val trainingRDD=splits(0)
    val testingRDD=splits(1)
    adjustALSParams(trainingRDD,testingRDD)
    spark.close()
  }

  def adjustALSParams(trainingRDD: RDD[Rating], testingData: RDD[Rating]):Unit={
      val result=for(rank<-Array(10,30,50,100,200);lambda<-Array(1,0.1,0.01,0.001))
        yield {
          val model=ALS.train(trainingRDD,rank,5,lambda)
          val rmse=getRMSE(model,testingData)
          (rank,lambda,rmse)
        }
    println(result.sortBy(_._3).head)
  }

  def getRMSE(model: MatrixFactorizationModel, testingData: RDD[Rating]):Double={
    //测试数据testingData里面的特征
    val usersProducts=testingData.map(item=>(item.user,item.product))
    //根据模型预测出来测试数据的评分
    val predictRating=model.predict(usersProducts)
    //真实评分
    val real=testingData.map(item=>((item.user,item.product),item.rating))
    //预测评分
    val predict=predictRating.map(item=>((item.user,item.product),item.rating))
    //计算RMSE
    sqrt(
      real.join(predict).map{
        case ((userId,productId),(real,pre))=>
          val err=real-pre
          err*err
      }.mean()
    )
  }

}
