package com.bluez;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.KeyValue;

import java.util.Properties;

/**
 * kafka升级成2.1.1版本后的写法
 */
public class Application {
    public static void main(String[] args) {
        // 定义Kafka broker的地址，这里是hdp01机器上的9091端口
        String brokers = "hdp01:9091";

        // 定义输入主题的名称为log，这个主题是数据的来源
        String from = "log";
        // 定义输出主题的名称为recommender，处理后的数据将发送到这个主题
        String to = "recommender";

        // 创建一个Properties对象，用于存储Kafka Streams的配置参数
        Properties settings = new Properties();
        // 设置应用程序的唯一标识符，这个标识符在Kafka集群中用于区分不同的Kafka Streams应用
        settings.put(StreamsConfig.APPLICATION_ID_CONFIG, "logFilter");
        // 设置Kafka broker的地址，告诉Kafka Streams应用连接到哪个Kafka集群
        settings.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, brokers);
        // 设置自定义的时间戳提取器类，用于处理输入记录的时间戳
        settings.put(StreamsConfig.DEFAULT_TIMESTAMP_EXTRACTOR_CLASS_CONFIG, CustomTimestampExtractor.class);

        // 根据设置的配置参数创建一个StreamsConfig对象，这个对象将被用于创建Kafka Streams实例
        StreamsConfig config = new StreamsConfig(settings);

        // 创建一个StreamsBuilder对象，它用于构建Kafka Streams应用的拓扑结构
        StreamsBuilder builder = new StreamsBuilder();
        // 从输入主题log中读取数据，开始构建拓扑
        builder.stream(from)
                // 对读取到的每条记录进行过滤操作
                .filter((key, value) -> {
                    // 将字节数组类型的value转换为字符串类型，以便进行后续的操作
                    String input = new String((byte[]) value);
                    // 打印出转换后的字符串内容，用于调试目的，查看输入数据的内容
                    System.out.println(input);
                    // 检查字符串是否包含特定的前缀PRODUCT_RATING_PREFIX:，如果包含则保留该记录，否则过滤掉
                    return input.contains("PRODUCT_RATING_PREFIX:");
                })
                // 对过滤后的数据进行映射操作
                .map((key, value) -> {
                    // 将字节数组类型的value转换为字符串类型，以便进行后续的操作
                    String input = new String((byte[]) value);
                    // 打印出转换后的字符串内容，用于调试目的，查看输入数据的内容
                    System.out.println(input);
                    // 以特定的前缀PRODUCT_RATING_PREFIX:为分隔符，将字符串分割并取后面的部分，然后去除首尾的空白字符
                    input = input.split("PRODUCT_RATING_PREFIX:")[1].trim();
                    // 打印出处理后的字符串内容，用于调试目的，查看映射操作后的结果
                    System.out.println(input);
                    // 将处理后的字符串转换为字节数组，同时将固定的字符串"logProcessor"也转换为字节数组，构建一个新的KeyValue对
                    return new KeyValue<>("logProcessor".getBytes(), input.getBytes());
                })
                // 将处理后的记录发送到输出主题recommender
                .to(to);

        // 根据构建好的StreamsBuilder构建一个Topology对象，这个对象代表了Kafka Streams应用的拓扑结构
        Topology topology = builder.build();

        // 根据构建好的拓扑结构和配置对象创建一个Kafka Streams实例
        KafkaStreams streams = new KafkaStreams(topology, config);

        // 启动Kafka Streams实例，开始处理数据
        streams.start();
        // 在控制台打印出提示信息，表示Kafka Streams已经启动
        System.out.println("kafka stream started!");
    }
}
