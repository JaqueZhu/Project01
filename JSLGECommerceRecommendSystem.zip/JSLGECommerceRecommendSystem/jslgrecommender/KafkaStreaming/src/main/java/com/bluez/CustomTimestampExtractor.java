package com.bluez;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.streams.processor.TimestampExtractor;

public class CustomTimestampExtractor implements TimestampExtractor {
    @Override
    public long extract(ConsumerRecord<Object, Object> consumerRecord, long l) {
        // 这里可以根据你的需求返回一个有效的时间戳
        // 例如，如果你的数据结构中包含时间相关的信息，可以从数据中提取并转换为时间戳
        // 为了简单起见，这里返回当前系统时间（以毫秒为单位）
        return System.currentTimeMillis();
    }
}