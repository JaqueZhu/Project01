package com.bluez.statistics

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

import java.text.SimpleDateFormat
import java.util.Date

case class Rating(userId:Int,productId:Int,score:Double,timestamp:Int)

case class MongoConfig(uri:String,db:String)

object StatisticsRecommender {

  val MONGODB_RATING_COLLECTION="Rating"

  val RATE_MORE_PRODUCTS="RateMoreProducts"
  val RATE_MORE_RECENTLY_PRODUCTS="RateMoreRecentlyProducts"
  val AVERAGE_PRODUCTS="AverageProducts"

  def main(args: Array[String]): Unit = {
    val config=Map(
      "spark.cores"->"local[*]",
      "mongo.uri"->"mongodb://192.168.137.100:27017/recommender",
      "mongo.db"->"recommender"
    )

    val sparkConf=new SparkConf().setAppName("StatisticsRecommender")
      .setMaster(config("spark.cores"))
      .set("spark.testing.memory","512000000")
    val spark=SparkSession.builder().config(sparkConf).getOrCreate()

    val mongoConfig=MongoConfig(config("mongo.uri"),config("mongo.db"))
    import spark.implicits._

    val ratingDF=spark.read
      .option("uri",mongoConfig.uri)
      .option("collection",MONGODB_RATING_COLLECTION)
      .format("com.mongodb.spark.sql")
      .load()
      .as[Rating]
      .toDF()

    ratingDF.createOrReplaceTempView("ratings")
    //不同的统计推荐结果
    //历史热门商品统计
    val rateMoreProductsDF=spark.sql("select productId,count(productId)as count from ratings group by productId")

    rateMoreProductsDF.write
      .option("uri",mongoConfig.uri)
      .option("collection",RATE_MORE_PRODUCTS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    //最近热门商品统计
    val simpleDateFormat=new SimpleDateFormat("yyyyMM")
    spark.udf.register("changeDate",(x:Int)=>simpleDateFormat
    .format(new Date(x*1000L)).toInt)

    val ratingOfYearMonth=spark.sql("select productId,score,changeDate(timestamp) as yearmonth from ratings")
    ratingOfYearMonth.createOrReplaceTempView("ratingOfMonth")

    val rateMoreRecentlyProducts=spark.sql("select productId,count(productId)as count,yearmonth from ratingOfMonth group by yearmonth,productId order by yearmonth desc,count desc")

    rateMoreRecentlyProducts.write
      .option("uri",mongoConfig.uri)
      .option("collection",RATE_MORE_RECENTLY_PRODUCTS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    //商品平均得分统计
    val averageProductsDF=spark.sql("select productId,avg(score) as avg from ratings group by productId")
    averageProductsDF
      .write
      .option("uri",mongoConfig.uri)
      .option("collection",AVERAGE_PRODUCTS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    spark.close()
  }
}
