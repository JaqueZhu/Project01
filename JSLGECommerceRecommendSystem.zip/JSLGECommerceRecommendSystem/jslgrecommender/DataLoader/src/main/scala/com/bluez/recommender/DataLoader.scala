package com.bluez.recommender

import com.mongodb.casbah.commons.MongoDBObject
import com.mongodb.casbah.{MongoClient, MongoClientURI}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}

case class Product(productId:Int,name:String,
                   imageUrl:String,categories:String,
                   tags:String)

case class Rating(userId:Int,productId:Int,
                  score:Double,timestamp:Int)

case class MongoConfig(uri:String,db:String)

object DataLoader {
  val PRODUCT_DATA_PATH="D:\\ProgramDemo\\IdeaProjects\\JSLGECommerceRecommendSystem\\jslgrecommender\\DataLoader\\src\\main\\resources\\films.csv"
  val RATING_DATA_PATH="D:\\ProgramDemo\\IdeaProjects\\JSLGECommerceRecommendSystem\\jslgrecommender\\DataLoader\\src\\main\\resources\\ratings.csv"

  val MONGODB_PRODUCT_COLLECTION="Product"
  val MONGODB_RATING_COLLECTION="Rating"



  def main(args: Array[String]): Unit = {
    val config=Map(
      "spark.cores"->"local[*]",
      "mongo.uri"->"mongodb://192.168.137.100:27017/recommender",
      "mongo.db"->"recommender"
    )
    val sparkConf=new SparkConf().setMaster(config("spark.cores"))
      .setAppName("DataLoader").set("spark.testing.memory","512000000")
    val spark=SparkSession.builder().config(sparkConf).getOrCreate()
    import spark.implicits._
    val productRDD=spark.sparkContext.textFile(PRODUCT_DATA_PATH)

    val productDF=productRDD.map(item=>{
      val attr=item.split(",")
      Product(attr(0).toInt,attr(1),attr(4),attr(5),attr(6))
    }).toDF()

    val ratingRDD=spark.sparkContext.textFile(RATING_DATA_PATH)
    val ratingDF=ratingRDD.map(item=>{
      val attr=item.split(",")
      Rating(attr(0).toInt,attr(1).toInt,attr(2).toDouble,attr(3).toInt)
    }).toDF()

    implicit  val mongoConfig=MongoConfig(config.get("mongo.uri").get,
      config.get("mongo.db").get)

    storeDataInMongoDB(productDF,ratingDF)

    spark.close()

  }

  def storeDataInMongoDB(productDF: DataFrame, ratingDF: DataFrame)
                        (implicit mongoConfig: MongoConfig): Unit = {
    val mongoClient=MongoClient(MongoClientURI(mongoConfig.uri))

    val productCollection=mongoClient(mongoConfig.db)(MONGODB_PRODUCT_COLLECTION)
    val ratingCollection=mongoClient(mongoConfig.db)(MONGODB_RATING_COLLECTION)

    productCollection.dropCollection()
    ratingCollection.dropCollection()

    productDF
      .write
      .option("uri",mongoConfig.uri)
      .option("collection",MONGODB_PRODUCT_COLLECTION)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    ratingDF
      .write
      .option("uri", mongoConfig.uri)
      .option("collection", MONGODB_RATING_COLLECTION)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    productCollection.createIndex(MongoDBObject("productId"->1))
    ratingCollection.createIndex(MongoDBObject("userId"->1))
    ratingCollection.createIndex(MongoDBObject("productId"->1))

    mongoClient.close()
  }


}
