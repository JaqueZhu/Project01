package com.bluez.content


import org.apache.spark.SparkConf
import org.apache.spark.ml.feature.{HashingTF, IDF, Tokenizer}
import org.apache.spark.ml.linalg.SparseVector
import org.apache.spark.sql.SparkSession
import org.jblas.DoubleMatrix

case class Product(productId: Int, name: String, imageUrl: String, categories: String, tags: String)

case class MongoConfig(uri: String, db: String)

// 定义标准推荐对象
case class Recommendation(productId: Int, score: Double)

// 定义商品相似度列表
case class ProductRecs(productId: Int, recs: Seq[Recommendation])

object ContentRecommender {
  // 定义mongodb中存储的表名
  val MONGODB_PRODUCT_COLLECTION = "Product"
  val CONTENT_PRODUCT_RECS = "ContentBasedProductRecs"

  def main(args: Array[String]): Unit = {
    val config = Map(
      "spark.cores" -> "local[*]",
      "mongo.uri" -> "mongodb://hdp01:27017/recommender",
      "mongo.db" -> "recommender"
    )
    // 创建一个spark config
    val sparkConf = new SparkConf().setMaster(config("spark.cores")).setAppName("ContentRecommender")
      .set("spark.testing.memory", "512000000")
    // 创建spark session
    val spark = SparkSession.builder().config(sparkConf).getOrCreate()

    import spark.implicits._
    implicit val mongoConfig = MongoConfig(config("mongo.uri"), config("mongo.db"))

    // 载入数据，做预处理
    val productTagsDF = spark.read
      .option("uri", mongoConfig.uri)
      .option("collection", MONGODB_PRODUCT_COLLECTION)
      .format("com.mongodb.spark.sql")
      .load()
      .as[Product]
      .map(
        x => (x.productId, x.name, x.tags.map(c => if (c == '|') ' ' else c))
      )
      .toDF("productId", "name", "tags")
      .cache()

    // TODO: 用TF-IDF提取商品特征向量
    // Tokenizer 是一个将文本字符串分割成单词的转换器
    // setInputCol("tags") 指定输入列 ，这里是 "tags"
    // setOutputCol("words") 指定输出列 ，这里是 "words"
    // transform(productTagsDF) 将分词器应用到 productTagsDF DataFrame 上 ，生成一个新的 DataFrame ，其中包含分词后的结果
    // 1. 实例化一个分词器，用来做分词，默认按照空格分
    val tokenizer = new Tokenizer().setInputCol("tags").setOutputCol("words")
    // 用分词器做转换，得到增加一个新列words的DF
    val wordsDataDF = tokenizer.transform(productTagsDF)

    // 2. 定义一个HashingTF工具，计算频次
    //    HashingTF 是一个将单词映射到一个固定大小的特征向量的工具 ，使用哈希技术来避免词汇表的稀疏性问题
    //    setInputCol("words") 指定输入列 ，这里是 "words"
    //    setOutputCol("rawFeatures") 指定输出列 ，这里是 "rawFeatures"
    //    setNumFeatures(800) 设置特征向量的维度为 800
    //    transform(wordsDataDF) 将哈希技术应用到分词后的 DataFrame 上 ，生成一个新的 DataFrame ，其中包含原始特征向量
    val hashingTF = new HashingTF().setInputCol("words").setOutputCol("rawFeatures").setNumFeatures(800)
    val featurizedDataDF = hashingTF.transform(wordsDataDF)

    // 3. 定义一个IDF工具，计算TF-IDF
    // IDF 计算逆文档频率 ，用于反映单词的稀有程度
    // setInputCol("rawFeatures") 指定输入列 ，这里是 "rawFeatures"
    // setOutputCol("features") 指定输出列 ，这里是 "features"
    // fit(featurizedDataDF) 训练 IDF 模型 ，计算每个单词的 IDF 值
    // transform(featurizedDataDF) 将 IDF 模型应用到原始特征向量上 ，生成一个新的 DataFrame ，其中包含调整后的特征向量
    val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features")
    // 训练一个idf模型
    val idfModel = idf.fit(featurizedDataDF)
    // 得到增加新列features的DF
    val rescaledDataDF = idfModel.transform(featurizedDataDF)

    // 对数据进行转换，得到RDD形式的features
    //    map 操作将每个行映射成一个包含产品 ID 和特征向量的元组
    //    row.getAs[Int]("productId") 获取产品 ID
    //    row.getAs[SparseVector]("features").toArray 获取特征向量并转换为数组
    //    .rdd 将 DataFrame 转换为 RDD
    //    map 操作将每个元组映射为包含产品 ID 和 DoubleMatrix 对象的元组
    val productFeatures = rescaledDataDF.map {
      row => (row.getAs[Int]("productId"), row.getAs[SparseVector]("features").toArray)
    }
      .rdd
      .map {
        case (productId, features) => (productId, new DoubleMatrix(features))
      }

    // 两两配对商品，计算余弦相似度
    val productRecs = productFeatures.cartesian(productFeatures)
      .filter {
        case (a, b) => a._1 != b._1
      }
      // 计算余弦相似度
      .map {
        case (a, b) =>
          val simScore = consinSim(a._2, b._2)
          (a._1, (b._1, simScore))
      }
      .filter(_._2._2 > 0.4)
      .groupByKey()
      .map {
        case (productId, recs) =>
          ProductRecs(productId, recs.toList.sortWith(_._2 > _._2).map(x => Recommendation(x._1, x._2)))
      }
      .toDF()
    productRecs.write
      .option("uri", mongoConfig.uri)
      .option("collection", CONTENT_PRODUCT_RECS)
      .mode("overwrite")
      .format("com.mongodb.spark.sql")
      .save()

    spark.stop()
  }

  def consinSim(product1: DoubleMatrix, product2: DoubleMatrix): Double = {
    product1.dot(product2) / (product1.norm2() * product2.norm2())
  }
}
